Skill Groomers CV AutoFill — Internal Chrome Extension
Version 1.1.0

WHAT HR DOES EACH DAY
1. Stay logged into Skill Groomers in Chrome.
2. Open the CV Analyzer and upload/analyse the CV.
3. Review the candidate and click Approve Candidate.
4. Click "Open Skill Groomers & Fill Candidate".
5. Skill Groomers opens and fills automatically.
6. Review the populated form and click Skill Groomers' own Save button.

ONE-TIME INSTALL
1. Extract this extension folder somewhere permanent on the HR computer.
2. In Chrome open: chrome://extensions
3. Turn on Developer mode.
4. Click "Load unpacked".
5. Select the extracted folder.
6. Leave the folder in that location; do not delete or move it.

SAFETY / SCOPE
- The extension runs only on the Skill Groomers Add Candidate page.
- It does not log into Skill Groomers.
- It does not read or store passwords, JWTs or cookies.
- It never clicks Save.
- HR remains in control of the final production save.
- Candidate data is carried in the URL fragment, decoded locally, and immediately removed from the visible URL.
- Exact website options are selected; if an exact option is not found, the extension leaves that field for HR review rather than guessing.
- Attachments, tags/source, communication, star rating, mandate and comments remain manual in this version.

TROUBLESHOOTING
- If nothing fills, make sure the extension is enabled and you opened Skill Groomers using the Analyzer button.
- If Skill Groomers redirects to login, log in normally, go back to the Analyzer, and click the button again.
- If a red notification lists fields to review, check only those fields manually before Save.
