(() => {
  "use strict";

  const LOG = "[SG CV AutoFill]";
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function toast(message, type = "info", timeout = 6500) {
    document.getElementById("sg-cv-autofill-toast")?.remove();
    const el = document.createElement("div");
    el.id = "sg-cv-autofill-toast";
    el.textContent = message;
    Object.assign(el.style, {
      position: "fixed",
      right: "22px",
      bottom: "22px",
      zIndex: "2147483647",
      maxWidth: "460px",
      padding: "13px 16px",
      borderRadius: "10px",
      color: "#fff",
      background: type === "error" ? "#b91c1c" : type === "success" ? "#047857" : "#334155",
      boxShadow: "0 10px 30px rgba(0,0,0,.22)",
      fontFamily: "Arial, sans-serif",
      fontSize: "14px",
      lineHeight: "1.45"
    });
    document.body.appendChild(el);
    setTimeout(() => el.remove(), timeout);
  }

  function decodeTransfer() {
    const match = location.hash.match(/(?:^#|[&#])cvfill=([^&]+)/);
    if (!match) return null;
    let token = decodeURIComponent(match[1]).replace(/-/g, "+").replace(/_/g, "/");
    while (token.length % 4) token += "=";
    const bytes = Uint8Array.from(atob(token), (c) => c.charCodeAt(0));
    return JSON.parse(new TextDecoder().decode(bytes));
  }

  function setNativeValue(el, value) {
    if (!el) return false;
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (!setter) return false;
    setter.call(el, value == null ? "" : String(value));
    el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: String(value ?? "") }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function fillDirect(field, value) {
    if (value === null || value === undefined || value === "") return false;
    const el = document.querySelector(`input[data-field="${field}"], textarea[data-field="${field}"]`);
    if (!el) return false;
    el.focus();
    const ok = setNativeValue(el, value);
    el.blur();
    return ok;
  }

  function fillDate(wrapperSelector, value) {
    if (!value) return false;
    const input = document.querySelector(`${wrapperSelector} input[type="text"]`);
    if (!input) return false;
    input.focus();
    const ok = setNativeValue(input, value);
    input.dispatchEvent(new Event("blur", { bubbles: true }));
    input.blur();
    return ok;
  }

  function hiddenByName(name) {
    return [...document.querySelectorAll('input[type="hidden"]')].find((el) => el.name === name) || null;
  }

  function selectInputByName(name) {
    const hidden = hiddenByName(name);
    if (!hidden) return null;
    let node = hidden.parentElement;
    for (let i = 0; node && i < 5; i++, node = node.parentElement) {
      const input = node.querySelector('input[role="combobox"]');
      if (input) return input;
    }
    return null;
  }

  function selectInputByField(field) {
    return document.querySelector(`[data-field="${field}"] input[role="combobox"]`);
  }

  function visibleOptions() {
    return [...document.querySelectorAll('[role="option"]')].filter((el) => {
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    });
  }

  async function waitForExactOption(text, timeout = 1800) {
    const wanted = String(text).trim().toLowerCase();
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const exact = visibleOptions().find((el) => (el.textContent || "").trim().toLowerCase() === wanted);
      if (exact) return exact;
      await sleep(80);
    }
    return null;
  }

  async function chooseExact(input, value, multi = false) {
    if (!input || value === null || value === undefined || value === "") return false;

    input.focus();
    input.click();
    setNativeValue(input, "");
    await sleep(70);
    setNativeValue(input, value);
    await sleep(180);

    const option = await waitForExactOption(value);
    if (!option) {
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
      input.blur();
      return false;
    }

    option.scrollIntoView({ block: "nearest" });
    option.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    option.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
    option.click();
    await sleep(150);

    if (!multi) input.blur();
    return true;
  }

  async function chooseByName(name, value) {
    return chooseExact(selectInputByName(name), value, false);
  }

  async function chooseByField(field, value) {
    return chooseExact(selectInputByField(field), value, false);
  }

  async function chooseSkills(skills) {
    const input = selectInputByField("keySkill");
    if (!input || !Array.isArray(skills)) return { count: 0, failed: skills || [] };
    let count = 0;
    const failed = [];
    for (const skill of skills.slice(0, 4)) {
      if (await chooseExact(input, skill, true)) count++;
      else failed.push(skill);
      await sleep(120);
    }
    input.blur();
    return { count, failed };
  }

  async function waitForForm(timeout = 12000) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      if (document.querySelector('input[data-field="fullName"]')) return true;
      await sleep(150);
    }
    return false;
  }

  async function attempt(label, fn, warnings) {
    try {
      const ok = await fn();
      if (!ok) warnings.push(label);
      return ok ? 1 : 0;
    } catch (e) {
      console.warn(LOG, label, e);
      warnings.push(label);
      return 0;
    }
  }

  async function fillCandidate(c) {
    let filled = 0;
    const warnings = [];

    // Core role first.
    if (c.coreRole) filled += await attempt("Core Role", () => chooseByField("coreRole", c.coreRole), warnings);

    // Personal details.
    for (const [label, field, value] of [
      ["Full Name", "fullName", c.fullName],
      ["Email", "emailId", c.emailId],
      ["Mobile", "mobileNumber", c.mobileNumber],
      ["Alternate Number", "alternateNumber", c.alternateNumber]
    ]) {
      if (value !== null && value !== undefined && value !== "") filled += await attempt(label, async () => fillDirect(field, value), warnings);
    }

    if (c.dateOfBirth) filled += await attempt("Date of Birth", async () => fillDate('[datafield="dateOfBirth"]', c.dateOfBirth), warnings);
    if (c.gender) filled += await attempt("Gender", () => chooseByName("Gender", c.gender), warnings);

    // Location selects are exact mapped labels only.
    for (const [label, name, value] of [
      ["Current City", "Current City", c.currentCity],
      ["Current State", "Current State", c.currentState],
      ["Native City", "Native City", c.nativeCity],
      ["Native State", "Native State", c.nativeState]
    ]) {
      if (value) filled += await attempt(label, () => chooseByName(name, value), warnings);
    }

    const skillResult = await chooseSkills(c.keySkills || []);
    filled += skillResult.count;
    warnings.push(...skillResult.failed.map((x) => `Key Skill: ${x}`));

    // Dependency order is important for React select children.
    if (c.functionalArea) {
      filled += await attempt("Functional Area", () => chooseByName("Functional Area", c.functionalArea), warnings);
      await sleep(300);
    }
    if (c.role) filled += await attempt("Role", () => chooseByName("Role", c.role), warnings);
    if (c.industry) filled += await attempt("Industry", () => chooseByName("Industry", c.industry), warnings);

    for (const [label, field, value] of [
      ["Current Designation", "currentDesignation", c.currentDesignation],
      ["Current Employer", "currentEmployer", c.currentEmployer],
      ["Previous Designation", "previousDesignation", c.previousDesignation],
      ["Previous Employer", "previousEmployer", c.previousEmployer],
      ["Total Number of Jobs", "totalNumberOfJobs", c.totalNumberOfJobs],
      ["Annual Salary", "annualSalaryLakh", c.annualSalaryLakh]
    ]) {
      if (value !== null && value !== undefined && value !== "") filled += await attempt(label, async () => fillDirect(field, value), warnings);
    }

    if (c.startDate) filled += await attempt("Current Start Date", async () => fillDate('[datafield="startDate"]', c.startDate), warnings);
    if (c.endDate) filled += await attempt("Current End Date", async () => fillDate('[datafield="endDate"]', c.endDate), warnings);

    if (c.totalExperienceInYears !== null && c.totalExperienceInYears !== undefined && c.totalExperienceInYears !== "") {
      filled += await attempt("Experience Years", () => chooseByField("totalExperienceInYears", c.totalExperienceInYears), warnings);
    }
    if (c.totalExperienceInMonths !== null && c.totalExperienceInMonths !== undefined && c.totalExperienceInMonths !== "") {
      filled += await attempt("Experience Months", () => chooseByField("totalExperienceInMonths", c.totalExperienceInMonths), warnings);
    }
    if (c.totalExperienceAsOfDate) filled += await attempt("Experience As Of", async () => fillDate('[datafield="totalExperienceAsOfDate"]', c.totalExperienceAsOfDate), warnings);
    if (c.averageTenureInYears !== null && c.averageTenureInYears !== undefined && c.averageTenureInYears !== "") {
      filled += await attempt("Average Tenure Years", () => chooseByField("averageTenureInYears", c.averageTenureInYears), warnings);
    }
    if (c.averageTenureInMonths !== null && c.averageTenureInMonths !== undefined && c.averageTenureInMonths !== "") {
      filled += await attempt("Average Tenure Months", () => chooseByField("averageTenureInMonths", c.averageTenureInMonths), warnings);
    }

    if (c.qualification) {
      filled += await attempt("Qualification", () => chooseByName("Qualification", c.qualification), warnings);
      await sleep(300);
    }
    if (c.course) {
      filled += await attempt("Course", () => chooseByName("Course", c.course), warnings);
      await sleep(300);
    }
    if (c.specialization) filled += await attempt("Specialization", () => chooseByName("Specialization", c.specialization), warnings);
    if (c.completionYear) filled += await attempt("Completion Year", async () => fillDirect("completionYear", c.completionYear), warnings);

    return { filled, warnings };
  }

  async function run() {
    let transfer;
    try {
      transfer = decodeTransfer();
    } catch (err) {
      console.error(LOG, err);
      toast("Could not read candidate data from CV Analyzer.", "error", 9000);
      return;
    }

    if (!transfer?.candidate) return; // Normal Add Candidate visit: do nothing.

    // Remove PII from the visible URL immediately after decoding it.
    history.replaceState(null, document.title, location.pathname + location.search);

    if (!(await waitForForm())) {
      toast("Skill Groomers Add Candidate form did not load. Refresh the page and try again from CV Analyzer.", "error", 10000);
      return;
    }

    toast("CV Analyzer detected. Filling Skill Groomers…", "info", 5000);
    const result = await fillCandidate(transfer.candidate);
    console.log(LOG, result);

    if (result.warnings.length === 0) {
      toast(`AutoFill complete. ${result.filled} fields/selections filled. Review and click Skill Groomers Save.`, "success", 8500);
    } else {
      const short = result.warnings.slice(0, 4).join(", ");
      const extra = result.warnings.length > 4 ? ` +${result.warnings.length - 4} more` : "";
      toast(`AutoFill completed with ${result.warnings.length} item(s) to review: ${short}${extra}.`, "error", 12000);
      console.warn(LOG, "Fields requiring review:", result.warnings);
    }
  }

  run();
})();
