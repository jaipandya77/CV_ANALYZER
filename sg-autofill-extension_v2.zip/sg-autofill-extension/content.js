(() => {
  "use strict";

  const LOG = "[SG CV AutoFill]";
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // --- INJECT MAIN WORLD SCRIPT (Bypasses CSP Error) ---
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("pageScript.js");
  (document.head || document.documentElement).appendChild(script);

  function toast(message, type = "info", timeout = 6500) {
    document.getElementById("sg-cv-autofill-toast")?.remove();
    const el = document.createElement("div");
    el.id = "sg-cv-autofill-toast";
    el.textContent = message;
    Object.assign(el.style, {
      position: "fixed", right: "22px", bottom: "22px", zIndex: "2147483647",
      maxWidth: "460px", padding: "13px 16px", borderRadius: "10px", color: "#fff",
      background: type === "error" ? "#b91c1c" : type === "success" ? "#047857" : "#334155",
      boxShadow: "0 10px 30px rgba(0,0,0,.22)", fontFamily: "Arial, sans-serif",
      fontSize: "14px", lineHeight: "1.45"
    });
    document.body.appendChild(el);
    setTimeout(() => el.remove(), timeout);
  }

  function decodeTransfer() {
    const match = location.hash.match(/(?:^#|[&#])(cvfill|cvdates)=([^&]+)/);
    if (!match) return null;
    const action = match[1];
    let token = decodeURIComponent(match[2]).replace(/-/g, "+").replace(/_/g, "/");
    while (token.length % 4) token += "=";
    const binaryStr = atob(token);
    const bytes = Uint8Array.from(binaryStr, (c) => c.charCodeAt(0));
    return { action: action, data: JSON.parse(new TextDecoder().decode(bytes)) };
  }

  function cleanForSearch(val) { return String(val || "").replace(/^['"]+|['"]+$/g, "").replace(/\s+/g, " ").trim(); }
  function normalizeText(val) { return String(val || "").toLowerCase().replace(/[^a-z0-9]/g, ""); }

  function setNativeValue(el, value) {
    if (!el) return false;
    let proto = (el instanceof HTMLTextAreaElement) ? HTMLTextAreaElement.prototype : 
                (el instanceof HTMLSelectElement) ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(el, value == null ? "" : String(value));
    else el.value = value == null ? "" : String(value);
    el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: String(value ?? "") }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function normalizeIndianPhone(value) {
    if (!value) return "";
    const digits = String(value).replace(/\D/g, "");
    if (digits.length === 10) return digits;
    if (digits.length === 12 && digits.startsWith("91")) return digits.slice(2);
    return String(value).trim();
  }

  function fillDirect(field, value) {
    if (!value) return false;
    const cleanField = field.replace(/[\[\]"]/g, "");
    const selector = `input[data-field="${cleanField}"], textarea[data-field="${cleanField}"], input[datafield="${cleanField}"], textarea[datafield="${cleanField}"], input[name="${cleanField}"], textarea[name="${cleanField}"], #${cleanField}`;
    const el = document.querySelector(selector);
    if (!el) return false;
    el.focus();
    const ok = setNativeValue(el, value);
    el.blur();
    return ok;
  }

  function hiddenByName(name) {
    const norm = normalizeText(name);
    return [...document.querySelectorAll('input[type="hidden"]')].find((el) => el.name === name || normalizeText(el.name) === norm) || null;
  }

  function selectInputByName(name) {
    const hidden = hiddenByName(name);
    if (hidden) {
      let node = hidden.parentElement;
      for (let i = 0; node && i < 6; i++, node = node.parentElement) {
        const input = node.querySelector('input[role="combobox"], input[aria-autocomplete="list"], input.ant-select-selection-search-input');
        if (input) return input;
      }
    }
    const norm = normalizeText(name);
    for (const lbl of document.querySelectorAll("label")) {
      if (normalizeText(lbl.textContent) === norm) {
        let parent = lbl.parentElement;
        for (let i = 0; parent && i < 4; i++, parent = parent.parentElement) {
          const input = parent.querySelector('input[role="combobox"], input[aria-autocomplete="list"], input');
          if (input) return input;
        }
      }
    }
    return null;
  }

  function selectInputByField(field) {
    const clean = field.replace(/[\[\]"]/g, "");
    return document.querySelector(`[data-field="${clean}"] input[role="combobox"], [datafield="${clean}"] input[role="combobox"], [data-field="${clean}"] input, [datafield="${clean}"] input`);
  }

  function visibleOptions() {
    return [...document.querySelectorAll('[role="option"], .ant-select-item-option-content')].filter(el => {
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    });
  }

  async function waitForOption(text, timeout = 2200) {
    const cleanWanted = cleanForSearch(text).toLowerCase();
    const normWanted = normalizeText(text);
    const deadline = Date.now() + timeout;

    while (Date.now() < deadline) {
      const options = visibleOptions();
      if (options.length > 0) {
        let exact = options.find(el => cleanForSearch(el.textContent).toLowerCase() === cleanWanted);
        if (exact) return exact;
        let normMatch = options.find(el => normalizeText(el.textContent) === normWanted);
        if (normMatch) return normMatch;
      }
      await sleep(80);
    }
    return null;
  }

  async function chooseExact(input, value, multi = false) {
    if (!input || !value) return false;
    const cleanVal = cleanForSearch(value);
    input.focus();
    input.click();
    input.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", code: "ArrowDown", bubbles: true }));
    await sleep(60);
    setNativeValue(input, "");
    await sleep(60);
    setNativeValue(input, cleanVal);
    await sleep(180);

    const option = await waitForOption(value);
    if (!option) {
      input.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
      input.blur();
      return false;
    }
    option.scrollIntoView({ block: "nearest" });
    option.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    option.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
    option.click();
    await sleep(160);
    if (!multi) input.blur();
    return true;
  }

  async function chooseByName(name, value) { return chooseExact(selectInputByName(name), value, false); }
  async function chooseByField(field, value) { return chooseExact(selectInputByField(field), value, false); }

  async function chooseSkills(skills) {
    const input = selectInputByField("keySkill");
    if (!input || !Array.isArray(skills)) return { count: 0, failed: skills || [] };
    let count = 0, failed = [];
    for (const skill of skills.slice(0, 4)) {
      if (await chooseExact(input, skill, true)) count++;
      else failed.push(skill);
      await sleep(130);
    }
    input.blur();
    return { count, failed };
  }

  async function attempt(label, fn, warnings) {
    try {
      const ok = await fn();
      if (!ok) warnings.push(label);
      return ok ? 1 : 0;
    } catch (e) {
      warnings.push(label);
      return 0;
    }
  }

  // --- TRIGGERS THE DOB INJECTION IN pageScript.js ---
  async function fillOnlyDates(c) {
    if (c.dateOfBirth) {
      window.postMessage({ type: "TRIGGER_DOB_FILL", date: c.dateOfBirth }, "*");
      return { filled: 1, warnings: [] };
    }
    return { filled: 0, warnings: ["Date of Birth missing"] };
  }

  async function fillCandidate(c) {
    let filled = 0;
    const warnings = [];

    if (c.coreRole) filled += await attempt("Core Role", () => chooseByField("coreRole", c.coreRole), warnings);

    for (const [label, field, value] of [
      ["Full Name", "fullName", c.fullName],
      ["Email", "emailId", c.emailId],
      ["Mobile", "mobileNumber", normalizeIndianPhone(c.mobileNumber)],
      ["Alternate Number", "alternateNumber", normalizeIndianPhone(c.alternateNumber)]
    ]) {
      if (value) filled += await attempt(label, async () => fillDirect(field, value), warnings);
    }

    if (c.gender) filled += await attempt("Gender", () => chooseByName("Gender", c.gender), warnings);

    for (const [label, name, value] of [
      ["Current City", "Current City", c.currentCity],
      ["Current State", "Current State", c.currentState],
      ["Native City", "Native City", c.nativeCity],
      ["Native State", "Native State", c.nativeState]
    ]) {
      if (value) filled += await attempt(label, () => chooseByName(name, value), warnings);
    }

    const skillResult = await chooseSkills(c.keySkills || []);
    filled += skillResult.count;
    warnings.push(...skillResult.failed.map((x) => `Key Skill: ${x}`));

    if (c.functionalArea) { filled += await attempt("Functional Area", () => chooseByName("Functional Area", c.functionalArea), warnings); await sleep(350); }
    if (c.role) filled += await attempt("Role", () => chooseByName("Role", c.role), warnings);
    if (c.industry) filled += await attempt("Industry", () => chooseByName("Industry", c.industry), warnings);

    for (const [label, field, value] of [
      ["Current Designation", "currentDesignation", c.currentDesignation],
      ["Current Employer", "currentEmployer", c.currentEmployer],
      ["Previous Designation", "previousDesignation", c.previousDesignation],
      ["Previous Employer", "previousEmployer", c.previousEmployer],
      ["Total Number of Jobs", "totalNumberOfJobs", c.totalNumberOfJobs],
      ["Annual Salary", "annualSalaryLakh", c.annualSalaryLakh]
    ]) {
      if (value) filled += await attempt(label, async () => fillDirect(field, value), warnings);
    }

    if (c.totalExperienceInYears) filled += await attempt("Experience Years", () => chooseByField("totalExperienceInYears", c.totalExperienceInYears), warnings);
    if (c.totalExperienceInMonths) filled += await attempt("Experience Months", () => chooseByField("totalExperienceInMonths", c.totalExperienceInMonths), warnings);
    if (c.averageTenureInYears) filled += await attempt("Average Tenure Years", () => chooseByField("averageTenureInYears", c.averageTenureInYears), warnings);
    if (c.averageTenureInMonths) filled += await attempt("Average Tenure Months", () => chooseByField("averageTenureInMonths", c.averageTenureInMonths), warnings);

    if (c.qualification) { filled += await attempt("Qualification", () => chooseByName("Qualification", c.qualification), warnings); await sleep(350); }
    if (c.course) { filled += await attempt("Course", () => chooseByName("Course", c.course), warnings); await sleep(350); }
    if (c.specialization) filled += await attempt("Specialization", () => chooseByName("Specialization", c.specialization), warnings);
    if (c.completionYear) filled += await attempt("Completion Year", async () => fillDirect("completionYear", c.completionYear), warnings);

    return { filled, warnings };
  }

  async function run() {
    let transfer;
    try { transfer = decodeTransfer(); } catch (err) { return; }
    if (!transfer || !transfer.data?.candidate) return;

    history.replaceState(null, document.title, location.pathname + location.search);

    let tries = 0;
    while (!document.querySelector('input[data-field="fullName"], input[name="fullName"]') && tries < 40) {
      await sleep(150); tries++;
    }

    if (transfer.action === "cvdates") {
      toast("Auto-filling Date of Birth...", "info", 3000);
      await fillOnlyDates(transfer.data.candidate);
      toast(`DOB Sync complete!`, "success", 5000);
    } else {
      toast("Filling main form...", "info", 5000);
      const result = await fillCandidate(transfer.data.candidate);
      if (result.warnings.length === 0) toast(`AutoFill complete!`, "success", 8500);
      else toast(`AutoFill done with ${result.warnings.length} warning(s)`, "error", 12000);
    }
  }

  run();
  window.addEventListener("hashchange", run);
})();