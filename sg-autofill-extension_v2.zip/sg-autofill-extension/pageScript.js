// pageScript.js
window.addEventListener("message", (event) => {
  if (event.data && event.data.type === "TRIGGER_DOB_FILL") {
    const dmyDate = event.data.date;
    try {
      const input = document.querySelector('input[placeholder="DD/MM/YYYY"]');
      if (!input) return;

      const parts = dmyDate.split("/");
      if (parts.length !== 3) return;
      const d = parseInt(parts[0]), m = parseInt(parts[1]), y = parseInt(parts[2]);

      const fiberKey = Object.keys(input).find(k => k.startsWith("__reactFiber$"));
      let fiber = input[fiberKey];
      let targetProps = null, picker = null;

      while (fiber) {
        if (fiber.stateNode && (fiber.stateNode.$picker || fiber.stateNode.picker)) {
          picker = fiber.stateNode.$picker?.data("daterangepicker") || fiber.stateNode.picker;
        }
        if (fiber.memoizedProps && fiber.memoizedProps.onBirthDateChange) {
          targetProps = fiber.memoizedProps;
        }
        if (picker && targetProps) break;
        fiber = fiber.return;
      }

      if (!picker && window.$) picker = window.$(input).data("daterangepicker");

      if (picker && picker.startDate) {
        const realMoment = picker.startDate.clone().year(y).month(m - 1).date(d).startOf("day");
        picker.setStartDate(realMoment);
        picker.setEndDate(realMoment);
        if (typeof picker.updateCalendars === "function") picker.updateCalendars();
        if (typeof picker.hide === "function") picker.hide();

        input.removeAttribute("readonly");
        input.value = dmyDate;
        
        const fakeEvent = { target: input, preventDefault: () => {} };
        if (typeof targetProps.onBirthDateChange === "function") {
          targetProps.onBirthDateChange(fakeEvent, picker);
        }
        input.setAttribute("readonly", "true");
        console.log("DOB successfully injected via React Fiber");
      }
    } catch (err) {
      console.error("[DOB Injection] Failed:", err);
    }
  }
});